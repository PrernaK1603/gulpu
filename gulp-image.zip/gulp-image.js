const gulp = require("gulp");
const spritesmith = require("gulp.spritesmith");
const imagemin = require("gulp-imagemin");
const fs = require("fs");
const log = require("fancy-log");
const jsonImg = JSON.parse(fs.readFileSync("./config/config.json")).images;

/* Change the directory after optimize the image*/

function imageArray(currTask, temp, index) {
  let files = [];
  let currPath = temp || currTask.srcDir;
  console.log(currPath, "currpath");
  if (index > 0 && currTask.tasks[index] == "minifyImage") {
    files.push(currPath + currTask.tempImg);
  } else {
    for (let k = 0; k < currTask.srcImg.length; k++) {
      files.push(currPath + currTask.srcImg[k]);
    }
  }
  console.log(files, "files");
  return files;
}

function minifyImage(currTask, temp, index) {
  console.log("Image Optimization Started...");
  let files = imageArray(currTask, temp, index);
  //console.log("Image Optimization Ended...");
  let promise = new Promise(function(resolve, reject) {
    gulp
      .src(files)
      .pipe(imagemin())
      .pipe(gulp.dest(currTask.tempImgDir))
      .on("end", function() {
        resolve(currTask.tempImgDir);
      });
  });
  return promise;
}

function imageSprite(currTask, temp, index) {
  console.log("ImageSprite Started...");
  let files = imageArray(currTask, temp, index);
  let spriteData = gulp.src(files).pipe(
    spritesmith({
      imgName: currTask.tempImg,
      cssName: currTask.tempScss
    })
  );
  console.log("ImageSprite Ended...");
  let promise = new Promise(function(resolve, reject) {
    spriteData.pipe(gulp.dest(currTask.tempImgDir)).on("end", function() {
      resolve(currTask.tempImgDir);
    });
  });
  return promise;
}

/* Distribution Function*/

function dist(currTask) {
  console.log("Dist Task Started...");
  console.log(currTask);
  console.log(currTask.tempImgDir + "*.*");
  console.log("Dist Task Ended");
  if (
    fs.access(currTask.tempImgDir, function(error) {
      if (error) {
        console.log("Error");
      } else {
        return gulp
          .src(currTask.tempImgDir + "*.*")
          .pipe(gulp.dest(currTask.dist));
      }
    })
  );
}

function runDist(currTask) {
  console.log("runDist Task Started...");
  console.log(currTask);
  console.log("runDist Task Ended...");
  fs.access(currTask.tempImgDir, function(error) {
    if (error) {
      console.log("Directory does not exist");
    } else {
      dist(currTask);
    }
  });
}

/* Synchronous recursive function*/

function SyncRecursiveApproach(temp, currTask, index) {
  if (index >= currTask.tasks.length) {
    return;
  }

  let strFunc = currTask.tasks[index];
  if (strFunc == "minifyImage") {
    let promise = minifyImage(currTask, temp, index);
    promise
      .then(function(path) {
        SyncRecursiveApproach(path, currTask, index + 1);
        runDist(currTask);
      })
      .catch(function() {
        console.log("minifyImage not perform");
      });
  } else if (strFunc == "imageSprite") {
    let promise = imageSprite(currTask, temp, index);
    promise
      .then(function(path) {
        SyncRecursiveApproach(path, currTask, index + 1);
        runDist(currTask);
      })
      .catch(function() {
        console.log("ImageSprite not perform");
      });
  }
}
/*Call both functions i.e minify_image and image_sprite*/

function imgTask(done) {
  console.log("Image Task Started...");
  let checkArray = jsonImg;
  if (Array.isArray(checkArray) && checkArray.length) {
    for (let i = 0; i < jsonImg.length; i++) {
      let storeObj = jsonImg[i].tasks;
      let currTask = jsonImg[i];
      let temp = "";

      if (storeObj == undefined) {
        console.log("Entered an incorrect task, Please enter a correct task");
      } else {
        if (Array.isArray(storeObj) && storeObj.length) {
          SyncRecursiveApproach(temp, currTask, 0);
        }
      }
    }
  }

  done();
  return;
}

const imageTasks = gulp.series(imgTask);
exports.imageTasks = imageTasks;
