def ConverttoCss(files):
    temp =[]
    scssFound = False
    k = 0 
    while k <len(files):
        if('s' in files[k]):
            scssFound = True
            temp.append(files[k])
            del(files[k])
            if(k!=0):
                k-=1
            else:
                k=0
        else:
            k+=1
        if(scssFound==False):
            print("No .Scss file present")
            return 0
    print("convert ot css")    
    return(temp)
def CssMC(cssOccured,temp,files,task):
    
    cssFound = False
    k = 0
    newFiles = []
    if cssOccured==False:
        while k <len(files):
            if('c' in files[k]):
                cssFound = True
                cssOccured=True
                newFiles.append(files[k]) 
                del(files[k])
                if(k!=0):
                    k-=1
                else:
                    k=0
            else:
                k+=1
            
    if(cssFound ==False and scssOccured==False and cssOccured==False):
        print("No .css file present")
        return 0
    if(scssOccured or cssOccured):
        newFiles+=temp
                
    temp+=newFiles
    if(task=="m"):
        print("uglify")
    if(task=="c"):
        print("Concat")
    return([temp,cssOccured])
'''def recursion(currObj,scssOccured,cssOccured,):
    if(currObj[j]=="s"):
        scssOccured = True
        temp = ConverttoCss(files)
            
    else:
        cssOutput = CssMC(cssOccured,temp,files,currObj[j])
        if(cssOutput):
            temp = cssOutput[0]
            cssOccured  = cssOutput[1]'''
    
    
ans = []


array = [["s"],["m"],["c"],["s","m"],["m","c"],["m","s"],["s","m","c"],["m","c","s"],["m","s","c"]]
for i in range(len(array)):
    temp = []
    files = ["s1","s2","s3","c1","c2"]
    currObj =  array[i]
    scssOccured = False
    cssOccured = False
    for j in range(len(currObj)):
        if(currObj[j]=="s"):
            scssOccured = True
            scssOutput = ConverttoCss(files)
            if(scssOutput):
                temp = scssOutput
            else:
                continue
        else:
            cssOutput = CssMC(cssOccured,temp,files,currObj[j])
            if(cssOutput):
                temp = cssOutput[0]
                cssOccured  = cssOutput[1]
            else:
                continue
    ans.append(temp)
    print(temp)

print(ans,"ans")


   