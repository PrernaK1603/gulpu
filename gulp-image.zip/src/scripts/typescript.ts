function hello(compiler: string) {
  console.log(`Hello from ${compiler}`);
}
hello("TypeScript");
