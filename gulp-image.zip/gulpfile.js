const gulp = require("gulp");
const clean = require("gulp-clean");
const del = require("del");

const gulp_css = require("./gulp-css.js");
const gulp_image = require("./gulp-image.js");
const gulp_js = require("./gulp-js.js");
const gulp_json = require("./gulp-json.js");
const gulp_html = require("./gulp-html.js");

gulp.task(
  "final",
  gulp.parallel(
    //gulp_css.cssTasks
    gulp_image.imageTasks,
    gulp_js.jsTasks
    // gulp_json.jsonTasks,
    // gulp_html.htmlTasks
  )
);

// gulp.task('clean', function () {
//   return gulp.src('temp', {read: false})
//       .pipe(clean());
// });

gulp.task("default", gulp.series("final"));
