function hello(compiler) {
    console.log("Hello from " + compiler);
}
hello("TypeScript");
