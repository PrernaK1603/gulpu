var gulp = require("gulp");
var uglify = require("gulp-uglify");
var concats = require("gulp-concat");
var fs = require("fs");
var jsonJs = JSON.parse(fs.readFileSync("./config/config.json")).js;

function jsArray(currTask, temp,index) {
  let files = [];
  console.log(index,"pppp");
  let currPath = temp || currTask.srcDir;
  console.log(currPath, "js array");
  if(index>0 && (currTask.tasks[index]=="minifyJs")){
    files.push(currPath+ currTask.concatejs);
  }
  else{
    for (var k = 0; k < currTask.srcJs.length; k++) {
      files.push(currPath + currTask.srcJs[k]);
      console.log(files, "jsss");
    }
  }
  return files;
}

function runDist(currTask, index, storeObj) {
  // let currTask = array[0];
  // let index = array[1];
  // let storeObj = array[2];
  console.log("runDist Task Started...", storeObj[index]);
  fs.access(currTask.tempJsDir, function(error) {
    if (error) {
      console.log("Directory does not exist");
    } else {
      //SyncRecursiveApproach(index + 1, storeObj);
      dist(currTask);
    }
  });
}

function SyncRecursiveApproach(temp,currTask,index, storeObj) {
  console.log(index,"sync index");
  console.log(storeObj,"store");
  if (index >= storeObj.length) {
    return;
  }
  let strFunc = storeObj[index];
  if (strFunc == "minifyJs") {
   var promise= minifyJs(index,currTask, temp);
      promise.then(function(path){
        SyncRecursiveApproach(path,currTask,index+1,storeObj);
        runDist(currTask, index, storeObj);
      }
        //runDist.bind(null, [currTask, index, storeObj])
        )
      .catch(function() {
        console.log("minify not perform");
      });
  } else if (strFunc == "concateJs") {
    console.log(temp, "concate file");
    var promise=concateJs(index,currTask, temp);
    promise.then(function(path){
      SyncRecursiveApproach(path,currTask,index+1,storeObj);
      runDist(currTask, index, storeObj);
    })
      .catch(function() {
        console.log("concate not perform");
      });
  }
  //temp = currTask.tempJsDir;
} 

function minifyJs(index,currTask, temp) {
  console.log("Js Minification Started...");
  console.log(temp, "js temp");
  let files = jsArray(currTask, temp,index);
  //file = currTask.tempJsDir;
  var promise= new Promise(function(resolve, reject) {
    if (Array.isArray(files) && files.length) {
      console.log(files, "minify");
      gulp
        .src(files)
        .pipe(uglify())
        .pipe(gulp.dest(currTask.tempJsDir))
        // .on("end", resolve);
        .on("end", function(){
          resolve(currTask.tempJsDir);
        });
    } else {
      gulp.on("error", reject);
    }
  });
  
  return promise;
}

function concateJs(index,currTask, temp) {
  console.log("Js Concatenation Started...");
  console.log(temp, "js conc temp");
  let files = jsArray(currTask, temp,index);
  //file = currTask.tempJsDir;
  var promise=new Promise(function(resolve, reject) {
    console.log(files, "concate");
    if (Array.isArray(files) && files.length) {
      gulp
        .src(files)
        .pipe(concats(currTask.concatejs))
        .pipe(gulp.dest(currTask.tempJsDir))
        .on("end", function(){
          resolve(currTask.tempJsDir);
        });
    } else {
      gulp.on("error", reject);
    }
  });
 
  return promise;
}

function dist(currTask) {
  console.log("Dist Task Started...");
  if (
    fs.access(currTask.tempJsDir, function(error) {
      if (error) {
        console.log("Error");
      } else {
        return gulp
          .src(currTask.tempJsDir + "*.*")
          .pipe(gulp.dest(currTask.dist));
      }
    })
  );
}

function jsTask(done) {
  console.log("Js Task Started...");
  var checkArray = jsonJs;
  if (Array.isArray(checkArray) && checkArray.length) {
    for (let i = 0; i < jsonJs.length; i++) {
      var temp = "";
      let storeObj = jsonJs[i].tasks;
      var currTask = jsonJs[i];
      if (storeObj == undefined) {
        console.log("Entered an incorrect task, Please enter a correct task");
      } else {
        if (Array.isArray(storeObj) && storeObj.length) {
          SyncRecursiveApproach(temp,currTask,0, storeObj);
          console.log("end sync");
        }
      }
    }
  }
  done();
return;
}

const jsTasks = gulp.series(jsTask);
exports.jsTasks = jsTasks;
