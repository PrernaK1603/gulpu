var gulp = require("gulp");
var clean = require('gulp-clean');
var del = require('del');

var gulp_css = require("./gulp-css.js");
var gulp_image = require("./gulp-image.js");
var gulp_js = require("./gulp-js.js");
var gulp_json = require("./gulp-json.js");
var gulp_html = require("./gulp-html.js");

gulp.task(
  "final",
  gulp.parallel(
    //gulp_css.cssTasks
    //gulp_image.imageTasks,
     gulp_js.jsTasks
    // gulp_json.jsonTasks,
    // gulp_html.htmlTasks
  )
);

// gulp.task('clean', function () {
//   return gulp.src('temp', {read: false})
//       .pipe(clean());
// });


gulp.task("default", gulp.series("final"));
