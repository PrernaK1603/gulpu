const gulp = require("gulp");
const sass = require("gulp-sass");
const cleanCss = require("gulp-clean-css");
const concatCss = require("gulp-concat");
const fs = require("fs");
const jsonCss = JSON.parse(fs.readFileSync("./config/config.json")).css;

function scssArray(currTask, temp) {
  console.log("SCSS ARRAY Started");
  let files = [];
  let currPath = temp || currTask.srcDir;
  console.log(currTask.srcCss);
  for (var k = 0; k < currTask.srcCss.length; k++) {
    var fileName = currTask.srcCss[k];
    var extension = fileName.split(".").pop();
    if (extension == "scss") {
      console.log(currTask.srcDir + currTask.srcCss[k]);
      files.push(currTask.srcDir + currTask.srcCss[k]);
    }
  }
  console.log("SCSS ARRAY Ended");
  return files;
}

// function cssArray(currTask, temp) {
//   console.log("CSS ARRAY Started");
//   let files = [];
//   let currPath = temp || currTask.srcDir;
//   console.log(currTask.srcCss);
//   for (var k = 0; k < currTask.srcCss.length; k++) {
//     var fileName = currTask.srcCss[k];
//     var extension = fileName.split(".").pop();
//     if (extension == "css") {
//       console.log(currPath + currTask.srcCss[k]);
//       files.push(currPath + currTask.srcCss[k]);
//     }
//   }
//   console.log("CSS ARRAY Ended");
//   return files;
// }

function cssArray(currTask, temp, index) {
  let files = [];
  console.log(index, "pppp");
  let currPath = temp || currTask.srcDir;
  console.log(currPath, "css array");
  if (index > 0 && currTask.tasks[index] == "minifyCss") {
    files.push(currPath + currTask.concatejs);
  } else if (currTask.tasks[index] == "convertJs") {
    let tsfileFound = false;
    for (let k = 0; k < currTask.srcJs.length; k++) {
      if (currTask.srcJs[k].split(".").pop() == "ts") {
        tsfileFound = true;
        files.push(currTask.srcDir + currTask.srcJs[k]);
      }
    }
    if (!tsfileFound) {
      console.log("No .ts file mentioned in", currTask.srcJs);
    }
  } else {
    let jsfileFound = false;
    for (let k = 0; k < currTask.srcJs.length; k++) {
      if (currTask.srcJs[k].split(".").pop() == "js") {
        jsfileFound = true;
        files.push(currPath + currTask.srcJs[k]);
      }
    }
    if (!jsfileFound) {
      console.log("No .js file mentioned in", currTask.srcJs);
    }
  }
  console.log(files, "jsss");
  return files;
}

function runDist(currTask) {
  console.log("runDist Task Started...");
  fs.access(currTask.tempCssDir, function(error) {
    if (error) {
      console.log("Directory does not exist");
    } else {
      dist(currTask);
    }
  });
}

// function SyncRecursiveApproach(temp, currTask, index) {
//   if (index >= currTask.tasks.length) {
//     return;
//   }

// //   let promise = CssTaskExecution(index, currTask, temp);
// //   promise
// //     .then(function(path) {
// //       SyncRecursiveApproach(path, currTask, index + 1);
// //       runDist(currTask);
// //     })
// //     .catch(function() {
// //       console.log("minify not perform");
// //     });
// // }

function CssTaskExecution(files, task, currTask,istempCreated) {
  
  let promise = new Promise(function(resolve, reject) {
    if (Array.isArray(files) && files.length > 0) {
      if (currTask.tasks[index] == "minifyCss") {

        gulp
          .src(files)
          .pipe(cleanCss())
          .pipe(gulp.dest(currTask.tempCssDir))
          .on("end", function() {
            resolve(currTask.tempCssDir);
          });
      } else if (currTask.tasks[index] == "concateCss") {
        let files = cssArray(currTask, temp, index);
        gulp
          .src(files)
          .pipe(concatCss(currTask.concatcss))
          .pipe(gulp.dest(currTask.tempCssDir))
          .on("end", function() {
            resolve(currTask.tempCssDir);
          });
      } else if (task== "ScssCss") {
        let files = scssArray(currTask, temp, index);
        gulp
          .src(files)
          .pipe(sass())
          .pipe(gulp.dest(currTask.tempCssDir))
          .on("end", function() {
            resolve("");
          });
      }
    } else {
      gulp.on("error", reject);
    }
  });

   return promise;
 }

function converttoCss(currTask,istempCreated){
  let files=[];
  let scssFound = false;
  let k  =0;
  while(k<currTask.tasks.length){
    let fileName = currTask.tasks[k];
    let extension = fileName.split(".").pop();
    if(extension=="scss")
    {
      scssFound = true;
      files.push(currTask.srcDir+fileName);
      currTask.tasks.splice(k,1);
      if(k!=0){
        k--;
      }else{
        k=0
      }
    }else{
      k++;
    }
  }
  if(scssFound==false){
    console.log("No .scss file present")
    return 0;
  }
  let promise  = CssTaskExecution(files,"ScssCss",currTask,istempCreated);
  promise.then(function(path) {
            //SyncRecursiveApproach(path, currTask, index + 1);
         runDist(currTask);
       })
       
  return files     
}
function MinifyConcateCss(scssOccured,cssOccured,temp,currtask){

  let cssFound = false;
  let k = 0;
  let files = [];
  if(cssOccured==false){
    
  while(k<currTask.tasks.length){
    let fileName = currTask.tasks[k];
    let extension = fileName.split(".").pop();
    if(extension=="css")
    {
      cssFound= true;
      cssOccured = true;
      files.push(currTask.srcDir+fileName);
      currTask.tasks.splice(k,1);
      if(k!=0){
        k--;
      }else{
        k=0
      }
    }else{
      k++;
    }
  }
  if(cssFound==false && scssOccured==false && cssOccured==false){
    console.log("No .css file present");
    return 0;
  }
  if(scssOccured || cssOccured){
     
     
  }


}
function dist(currTask) {
  console.log("Dist Task Started...");
  if (
    fs.access(currTask.tempCssDir, function(error) {
      if (error) {
        console.log("Error");
      } else {
        return gulp
          .src(currTask.tempCssDir + "*.*")
          .pipe(gulp.dest(currTask.dist));
      }
    })
  );
}

function cssTask(done) {
  console.log("Css Task Started...");
  const checkArray = jsonCss;
  if (Array.isArray(checkArray) && checkArray.length) {
    for (let i = 0; i < jsonCss.length; i++) {
      let temp = [];
      let istempCreated = ""
      let storeObj = jsonCss[i].tasks;
      let currTask = jsonCss[i];
      let scssOccured=false;
      let cssOccured=false;
      if (storeObj == undefined) {
        console.log("Entered an incorrect task, Please enter a correct task");
      } else {
        if (Array.isArray(storeObj) && storeObj.length) {
          for(let j=0;j<storeObj.length;j++){
            if(storeObj[j]=="scssCss"){
              scssOccured=true;
              let scssOutput=converttoCss(currTask,istempCreated);
              if(scssOutput){
                temp=scssOutput;
              }
              else{
                continue;
              }
            }
            else{
              let cssOutput=MinifyConcateCss(scssOccured,cssOccured,temp,currtask)
              if(cssOutput){
                temp=cssOutput[0];
                cssOccured=cssOutput[1];
              }else{
                continue;
              }
            }
          }
          console.log(temp,"temp");
          console.log("end sync");
        }
      }
    }
  }
  done();
  return;
}

const cssTasks = gulp.series(cssTask);
exports.cssTasks = cssTasks;
